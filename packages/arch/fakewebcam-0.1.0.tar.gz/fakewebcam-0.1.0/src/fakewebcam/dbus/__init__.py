#!/usr/bin/env

from .fakewebcamobject import FakeWebcamObject

BUS_NAME = "com.github.radium226.FakeWebcam"