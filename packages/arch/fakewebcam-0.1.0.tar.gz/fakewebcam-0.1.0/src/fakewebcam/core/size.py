#!/usr/bin/env python

from collections import namedtuple

Size = namedtuple("Size", ["width", "height"])