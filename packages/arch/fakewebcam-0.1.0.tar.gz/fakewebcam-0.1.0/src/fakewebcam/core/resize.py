#!/usr/bin/env python

def resize():