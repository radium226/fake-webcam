# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['fakewebcam',
 'fakewebcam.click',
 'fakewebcam.client',
 'fakewebcam.core',
 'fakewebcam.dbus',
 'fakewebcam.server']

package_data = \
{'': ['*']}

install_requires = \
['click>=7.1.2,<8.0.0',
 'dbus-python>=1.2.16,<2.0.0',
 'mediainfo>=0.0.8,<0.0.9',
 'numpy>=1.18.5,<2.0.0',
 'opencv-python>=4.2.0,<5.0.0',
 'pygobject>=3.36.1,<4.0.0',
 'pyudev>=0.22.0,<0.23.0',
 'rx>=3.1.0,<4.0.0']

entry_points = \
{'console_scripts': ['fake-webcam = fakewebcam:run']}

setup_kwargs = {
    'name': 'fakewebcam',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Adrien',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
